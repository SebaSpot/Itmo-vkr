from django.apps import AppConfig


class CoursConfig(AppConfig):
    name = 'cours'
