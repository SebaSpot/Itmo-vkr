Project SDO by VKR
